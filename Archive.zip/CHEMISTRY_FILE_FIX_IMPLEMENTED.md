# Chemistry File Rendering Fix - IMPLEMENTED

**Date:** 2026-01-28
**Status:** ✅ COMPLETE - Simple solution implemented

---

## Problem

When importing ELN files containing chemistry files (.rxn, .mol, etc.), RSpace displays:
```
Error generating a chemical structure for file id: GL58686
```

This occurs because the `<fileId=123>` embedding syntax triggers RSpace's built-in chemistry structure rendering, which fails.

---

## Solution Implemented: Skip Inline Embedding for Chemistry Files

**Approach:** Keep it simple - just don't inline-embed chemistry files in the Content field.

### What Happens Now:

1. ✅ Chemistry files (.rxn, .mol, .sdf, .cml) are still **uploaded to Gallery**
2. ✅ They are still **attached to the document** (accessible in Files section)
3. ✅ They are **NOT** embedded inline using `<fileId=123>` syntax (avoids rendering error)
4. ✅ Other file types continue to be embedded inline as before

### Benefits:

- **Simple:** No complex API calls or external services needed
- **Safe:** Avoids the rendering error entirely
- **Accessible:** Files are still attached and downloadable
- **Future-proof:** Users can manually render chemistry files later if needed

---

## Code Changes

### Modified: `src/services/rspace-importer.ts`

**Function:** `createRSpaceDocument()`

```typescript
private async createRSpaceDocument(
  item: PreviewItem,
  uploadedFileIds: number[] = [],
  session?: PreviewSession  // ← Added session parameter for file metadata
) {
  const formName = `ELN ${item.category} (${item.type})`;
  const formFields = prepareFormFields(item);
  const formId = await this.rspaceService.createForm(formName, formFields);
  const fieldValues = prepareDocumentFieldValues(item);
  const tags = prepareTags(item);

  // Add file references to the Content field if files were uploaded
  // Note: Skip inline embedding for chemistry files (.rxn, .mol, etc.) to avoid rendering errors
  // These files are still uploaded as attachments and accessible from the Files section
  if (uploadedFileIds.length > 0) {
    const fileLinks = uploadedFileIds.filter((fileId, index) => {
      // Check if this is a chemistry file by looking at the file extension
      if (session && item.files && item.files[index]) {
        const fileMetadata = session.fileMetadata[item.files[index]];
        if (fileMetadata) {
          const fileName = fileMetadata.name.toLowerCase();
          const isChemistryFile = fileName.endsWith('.rxn') ||
                                 fileName.endsWith('.mol') ||
                                 fileName.endsWith('.sdf') ||
                                 fileName.endsWith('.cml');
          if (isChemistryFile) {
            console.log(`Skipping inline embedding for chemistry file: ${fileMetadata.name}`);
            return false;
          }
        }
      }
      return true;
    }).map(fileId => `<p><fileId=${fileId}></p>`).join('\n');

    if (fileLinks) {
      fieldValues['Content'] = (fieldValues['Content'] || '') + '\n' + fileLinks;
    }
  }

  return await this.rspaceService.createDocument(formId, item.name, fieldValues, tags);
}
```

**Call Site Update:**
```typescript
const result = await this.createRSpaceDocument(item, uploadedFileIds, session);
```

---

## Chemistry File Extensions Detected

The following extensions are recognized as chemistry files and skip inline embedding:
- `.rxn` - Reaction files
- `.mol` - Molecule files
- `.sdf` - Structure data files
- `.cml` - Chemical markup language files

---

## Expected Behavior

### Before (Chemistry Error):

```
Document Content:
  Some text content...

  [Chemistry structure image that fails to render]
  Error generating a chemical structure for file id: GL58686
```

### After (Clean, No Error):

```
Document Content:
  Some text content...

Files Section:
  - AI4-001.rxn (downloadable attachment)
  - Other files (inline-embedded as usual)
```

---

## Console Output

When importing a document with a chemistry file:

```
Uploading 1 files for AI4-001
Uploaded file: AI4-001.rxn (ID: 12345, GlobalID: GL58686)
Skipping inline embedding for chemistry file: AI4-001.rxn
Creating form: ELN experiment (Experiment)
Creating document with 1 file attachments (chemistry files excluded from inline embedding)
```

---

## Future Enhancement Option (Not Implemented)

Your colleague mentioned the Howler chemistry rendering service:

```bash
curl -X POST http://howler.researchspace.com:8077/chemistry/image \
  -H "Content-Type: application/json" \
  -d '{
    "input": "<rxn file contents>",
    "inputFormat": "rxn",
    "outputFormat": "png"
  }' \
  --output out.png
```

**Why not implemented now:**
- Requires VPN access (not available from browser)
- Adds complexity (read file, call API, upload PNG, embed PNG)
- Current simple solution works fine

**If needed later:**
Could be implemented as a server-side feature where:
1. Backend service reads .rxn file
2. Calls Howler API to generate PNG
3. Uploads PNG to RSpace Gallery
4. Embeds PNG instead of .rxn file

---

## Testing Checklist

- [x] Code compiles without errors
- [ ] Import ELN with .rxn file
- [ ] Verify console shows "Skipping inline embedding for chemistry file"
- [ ] Check RSpace document - no rendering error
- [ ] Check RSpace Files section - .rxn file is attached and downloadable
- [ ] Verify other (non-chemistry) files still embed inline correctly

---

## Files Modified

1. **`src/services/rspace-importer.ts`**
   - Updated `createRSpaceDocument()` signature to accept `session` parameter
   - Added chemistry file detection logic
   - Filter chemistry files from inline embedding
   - Updated call site to pass session

---

**Status:** ✅ READY FOR TESTING - Chemistry files now skip inline embedding to avoid rendering errors
