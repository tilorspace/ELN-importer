# Chemistry File Rendering Issue (.rxn files)

**Date:** 2026-01-28
**Issue:** RSpace shows "Error generating a chemical structure for file id: GL58686" for .rxn files

---

## Problem

When importing chemistry files (`.rxn`, `.mol`, etc.), RSpace tries to render them as chemical structures but fails with an error message instead of showing the structure.

### Example Error
```
Error generating a chemical structure for file id: GL58686
```

---

## Root Cause

**Current code:** `src/services/rspace-importer.ts` lines 220-226

```typescript
// Add file references to the Content field if files were uploaded
// Use RSpace's special <fileId=ID> syntax which it will automatically render as proper links
if (uploadedFileIds.length > 0) {
  const fileLinks = uploadedFileIds.map(fileId =>
    `<p><fileId=${fileId}></p>`  // ← This triggers chemical structure rendering
  ).join('\n');
  fieldValues['Content'] = (fieldValues['Content'] || '') + '\n' + fileLinks;
}
```

**What happens:**
1. `.rxn` file uploaded to Gallery → Gets ID like 123
2. Embedded in document as `<fileId=123>`
3. RSpace detects it's a chemistry file (`.rxn` extension)
4. RSpace tries to render it as a chemical structure
5. **Rendering fails** → Shows error message instead

**Why it fails:**
- Could be RSpace chemistry rendering engine issue
- Could be file format incompatibility
- Could be missing chemistry plugin/library
- Could be permissions or configuration issue

---

## Solutions

### Option 1: Use Image Embedding (Recommended)

RSpace has special syntax for embedding files as images vs. structures:

```typescript
// Instead of:
`<fileId=${fileId}>`

// Try:
`<img src="/gallery/${fileId}" />`
```

This should show the file as a Gallery thumbnail/link instead of trying to render the chemistry.

### Option 2: Use Chemistry-Specific Syntax

RSpace might have special syntax for chemistry files:

```typescript
// Possible alternatives:
`<chemId=${fileId}>`        // Chemistry-specific
`<rxnId=${fileId}>`         // Reaction-specific
`<molId=${fileId}>`         // Molecule-specific
```

Need to check RSpace documentation for correct syntax.

### Option 3: Detect File Type and Use Appropriate Syntax

Smart approach - use different embedding based on file type:

```typescript
private createFileEmbedding(fileId: number, fileName: string): string {
  const ext = fileName.toLowerCase().split('.').pop();

  // Chemistry files - use special handling to avoid rendering errors
  if (['rxn', 'mol', 'sdf', 'cml'].includes(ext || '')) {
    // Option A: Link only (no inline rendering)
    return `<p><a href="/gallery/${fileId}">${fileName}</a></p>`;

    // Option B: Image thumbnail
    return `<p><img src="/gallery/${fileId}/thumbnail" alt="${fileName}" /></p>`;

    // Option C: Try chemistry syntax (if it exists)
    return `<p><chemId=${fileId}></p>`;
  }

  // Regular files - use standard fileId syntax
  return `<p><fileId=${fileId}></p>`;
}
```

### Option 4: Attachment Instead of Embedding

Don't embed chemistry files inline at all - just attach them:

```typescript
if (uploadedFileIds.length > 0) {
  // For chemistry files, just attach them (already done via API)
  // Don't add to Content field

  // OR add a note mentioning attachments:
  fieldValues['Content'] += '\n<p>See attached chemistry files (.rxn)</p>';
}
```

---

## Investigation Needed

### Questions for User

1. **Does RSpace chemistry rendering work elsewhere?**
   - Can you manually create a document and embed a .rxn file that renders correctly?
   - Does `<fileId=XXX>` work for .rxn files when done manually?

2. **What should .rxn files look like?**
   - Should they render as chemical structures?
   - Or just show as file links/downloads?

3. **RSpace chemistry configuration:**
   - Is there a chemistry plugin installed?
   - Are there special permissions needed?
   - Is there documentation for chemistry file syntax?

### Tests to Run

1. **Manual test in RSpace UI:**
   - Upload a .rxn file to Gallery
   - Create a new document
   - Try embedding it with different syntaxes:
     - `<fileId=123>`
     - `<img src="/gallery/123" />`
     - `<chemId=123>`
   - See which works without error

2. **Check RSpace version:**
   - What version is installed?
   - Is chemistry support enabled?
   - Check RSpace release notes for chemistry features

3. **Inspect working example:**
   - Find a document in RSpace that DOES show chemistry structures correctly
   - View source to see what HTML syntax it uses
   - Copy that syntax in our importer

---

## Recommended Implementation

**Quick fix (safe):** Use file links instead of inline rendering for chemistry files

```typescript
private async createRSpaceDocument(item: PreviewItem, uploadedFileIds: number[] = []) {
  const formName = `ELN ${item.category} (${item.type})`;
  const formFields = prepareFormFields(item);
  const formId = await this.rspaceService.createForm(formName, formFields);
  const fieldValues = prepareDocumentFieldValues(item);
  const tags = prepareTags(item);

  // Add file references to the Content field if files were uploaded
  if (uploadedFileIds.length > 0) {
    const fileLinks = uploadedFileIds.map((fileId, index) => {
      const fileName = item.files[index] || `file-${fileId}`;
      const fileMetadata = session.fileMetadata[fileName];
      const ext = fileMetadata?.encodingFormat?.split('/').pop() || '';

      // Chemistry files - use link to avoid rendering errors
      if (ext.includes('rxn') || ext.includes('mol') || ext.includes('cml')) {
        return `<p><a href="/gallery/${fileId}">${fileMetadata?.name || 'Chemistry file'}</a></p>`;
      }

      // Regular files - use RSpace fileId syntax
      return `<p><fileId=${fileId}></p>`;
    }).join('\n');

    fieldValues['Content'] = (fieldValues['Content'] || '') + '\n' + fileLinks;
  }

  return await this.rspaceService.createDocument(formId, item.name, fieldValues, tags);
}
```

---

## Alternative: Chemistry Structure Rendering

If RSpace SHOULD render chemistry files but isn't, the issue might be:

1. **File upload endpoint:** Maybe chemistry files need to go to a different endpoint
2. **File metadata:** Maybe we need to set specific metadata for chemistry files
3. **RSpace configuration:** Chemistry rendering might need to be enabled
4. **File content:** The .rxn file might have formatting RSpace doesn't understand

---

## Next Steps

1. **Test manually** - Can user make .rxn files render in RSpace UI?
2. **Check documentation** - What's the correct syntax for chemistry files?
3. **Implement fix** - Use file links or correct chemistry syntax
4. **Test import** - Verify chemistry files work without errors

---

**Status:** ✅ RESOLVED - See CHEMISTRY_FILE_FIX_IMPLEMENTED.md for the implemented solution

## Resolution

After discussion with the team, implemented a simple solution:
- Chemistry files (.rxn, .mol, .sdf, .cml) are **uploaded and attached** to documents
- They are **NOT embedded inline** using `<fileId=123>` syntax
- This avoids the rendering error entirely
- Files remain accessible in the Files/Attachments section

The Howler API option was considered but deemed too complex for the current needs:
- Requires VPN access (not available from browser)
- Would require backend service integration
- Current simple solution is sufficient
